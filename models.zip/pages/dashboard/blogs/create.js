import React, { useState } from 'react'
import classes from "~/components/ProductForm/productForm.module.css";
import { toast } from "react-toastify";
import FileUpload from "../../../components/FileUpload/fileUpload";
import TextEditor from '~/components/TextEditor';
import { postData } from '~/lib/clientFunctions';


const create = () => {
    const [editorState, setEditorState] = useState("");
    const [name, setName] = useState("");
    const [image, setImage] = useState(null);



    const submitHandler = async (e) => {
        e.preventDefault();
        try {
            
            const formData = new FormData();
            formData.append("name",name)
            formData.append("description",editorState)
            formData.append("image",image)
            const response = await postData(`${process.env.NEXT_PUBLIC_API}/mobile/createblog`, formData);
            response.success
                ? (toast.success("Blog Added Successfully"), form.reset())
                : toast.error("Something Went Wrong");
        } catch (err) {
            console.log(err);
            toast.error("Something Went Wrong");
        }

    }
    const updatedValueCb = (data) => {
        setEditorState(data);
    };
    return (
        <>
            <h4 className="text-center pt-3 pb-5">Create New Blog</h4>
            <form id="blog_form" onSubmit={submitHandler}>
                <div className="mb-5">
                    <label htmlFor="inp-1" className="form-label">
                        Title*
                    </label><br />

                    <input onChange={(e) => { setName(e.target.value) }} value={name} style={{ width: "100%", height: "50px" }} type="text" id="inp-1" name="code" required />
                </div>
                <div className="mb-5">
                    <label htmlFor="inp-2" className="form-label">
                        Descripction*
                    </label>
                    <TextEditor
                        previousValue={editorState}
                        updatedValue={updatedValueCb}
                        height={300}
                    />                </div>
                <div className="mb-5">
                <label htmlFor="inp-2" className="form-label">
                        Upload Image*
                    </label>
                <input type="file"
                  onChange={(e)=>{setImage(e.target.files[0])}}
       accept="image/png, image/jpeg" />
                    
                </div>
                <div className="mb-4">
                    <input type="submit" value="Add Blog" className="btn btn-success" />
                </div>
            </form>
        </>
    )
}

create.requireAuthAdmin = true;
create.dashboard = true;

export default create