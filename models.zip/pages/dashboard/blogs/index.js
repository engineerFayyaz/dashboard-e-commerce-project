import { Delete, NotepadEdit } from "@styled-icons/fluentui-system-regular";
import dynamic from "next/dynamic";
import Link from "next/link";
import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import useSWR from "swr";
import classes from "~/components/tableFilter/table.module.css";
import { deleteData, fetchData } from "~/lib/clientFunctions";

const DataTable = dynamic(() => import("react-data-table-component"));
const FilterComponent = dynamic(() => import("~/components/tableFilter"));
const GlobalModal = dynamic(() => import("~/components/Ui/Modal/modal"));
const Spinner = dynamic(() => import("~/components/Ui/Spinner"));

const Blogs = () => {
  const url = `${process.env.NEXT_PUBLIC_API}/mobile/getblogs`;
  const { data, error, mutate } = useSWR(url, fetchData);

  const [blogList, setBlogList] = useState([]);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedBlog, setSelectedBlog] = useState("");

  useEffect(() => {
    if (data && data.blogs) {
        setBlogList(data.blogs);
    }
  }, [data]);

  const openModal = (id) => {
    setSelectedBlog(id);
    setIsOpen(true);
  };
  const closeModal = () => {
    setIsOpen(false);
  };
  const deleteBlog = async () => {
    setIsOpen(false);
    await deleteData(`/api/deleteblog/${selectedBlog}`)
      .then((data) =>
        data.success
          ? (toast.success("Blog Deleted Successfully"), mutate())
          : toast.error("Something Went Wrong"),
      )
      .catch((err) => {
        console.log(err);
        toast.error("Something Went Wrong");
      });
  };

  const [filterText, setFilterText] = React.useState("");
  const [resetPaginationToggle, setResetPaginationToggle] =
    React.useState(false);
  const filteredItems = blogList.filter(
    (item) =>
      item.name && item.name.toLowerCase().includes(filterText.toLowerCase()),
  );

  const subHeaderComponentMemo = React.useMemo(() => {
    const handleClear = () => {
      if (filterText) {
        setResetPaginationToggle(!resetPaginationToggle);
        setFilterText("");
      }
    };
    return (
      <FilterComponent
        onFilter={(e) => setFilterText(e.target.value)}
        onClear={handleClear}
        filterText={filterText}
      />
    );
  }, [filterText, resetPaginationToggle]);

  const customStyles = {
    rows: {
      style: {
        minHeight: "92px",
        fontSize: "15px",
      },
    },
    headCells: {
      style: {
        fontSize: "15px",
      },
    },
  };

  const columns = [
    {
        name: "Id",
        selector: (row) => row._id,
      //   sortable: true,
      },
    {
      name: "Name",
      selector: (row) => row.name,
      sortable: true,
    },
    {
        name: "Date",
        selector: (row) => new Date(row.date).toLocaleDateString(),
      },
    {
      name: "Action",
      selector: (row) => (
        <div>
          <div className={classes.button} onClick={() => openModal(row._id)}>
            <Delete width={30} height={30} title="DELETE" />
          </div>
          <Link href={`/dashboard/blogs/${row.slug}`}>
            <a>
              <div className={classes.button}>
                <NotepadEdit width={30} height={30} title="EDIT" />
              </div>
            </a>
          </Link>
        </div>
      ),
    },
  ];

  return (
    <>
      {error ? (
        <h3 className="text-center text-danger">failed to load</h3>
      ) : !data ? (
        <Spinner />
      ) : (
        <div className={classes.container}>
          <DataTable
            columns={columns}
            data={filteredItems}
            pagination
            paginationResetDefaultPage={resetPaginationToggle}
            subHeader
            subHeaderComponent={subHeaderComponentMemo}
            persistTableHead
            customStyles={customStyles}
          />
        </div>
      )}
      <GlobalModal isOpen={isOpen} handleCloseModal={closeModal} small={true}>
        <div className={classes.modal_icon}>
          <Delete width={90} height={90} />
          <p className="mb-3">Are you sure, you want to delete?</p>
          <div>
            <button
              className={classes.danger_button}
              onClick={() => deleteBlog()}
            >
              Delete
            </button>
            <button
              className={classes.success_button}
              onClick={() => closeModal()}
            >
              Cancel
            </button>
          </div>
        </div>
      </GlobalModal>
    </>
  );
};

Blogs.requireAuthAdmin = true;
Blogs.dashboard = true;

export default Blogs;
