
import classes from "../../../components/ProductForm/productForm.module.css";
import FileUpload from "../../../components/FileUpload/fileUpload";
import { useRouter } from "next/router";
import useSWR from "swr";
import { fetchData, postData } from "~/lib/clientFunctions";
import { useEffect, useState } from "react";
import Spinner from "../../../components/Ui/Spinner/index";
import DefaultErrorPage from "next/error";
import TextEditor from '~/components/TextEditor';
import { toast } from "react-toastify";

const editBlog = () => {

  const [editorState, setEditorState] = useState("");
  const [name, setName] = useState("");
  const [image, setImage] = useState(null);

    const router = useRouter();
    const url = `${process.env.NEXT_PUBLIC_API}/getblog/${router.query.id}`;
    const { data, error } = useSWR(router.query.id ? url : null, fetchData);
 
    const submitHandler = async (e) => {
        e.preventDefault();
        try {
          const formData = new FormData();
          formData.append("name",name)
            formData.append("description",editorState)
            if(image){
              formData.append("image",image)   
            }else{
              formData.append("image",blog.image)
            }
          const response = await postData(`${process.env.NEXT_PUBLIC_API}/editblog/${blog._id}`, formData);
          response.success
            ? toast.success("Blog Updated Successfully")
            : toast.error("Something Went Wrong");
        } catch (err) {
          console.log(err);
          toast.error("Something Went Wrong");
        }
      };
console.log('data', data)
const updatedValueCb = (data) => {
  setEditorState(data);
};
const[blog, setBlog] = useState({});

useEffect(() => {
  if (data && data) {
   setName(data.blog.name)
   setEditorState(data.blog.description);
    setBlog(data.blog)
  }
}, [data]);

  return (


    <>
    {error ? (
        <DefaultErrorPage statusCode={500} />
      ) : !data ? (
        <Spinner />
      ) : (
        <div>
        <h4 className="text-center pt-3 pb-5">Edit Blog</h4>
        <form id="blog_form" onSubmit={submitHandler}>
        <input type="hidden" name="id" defaultValue={blog._id} />
            <div className="mb-5">
              <label htmlFor="inp-1" className="form-label">
                Title*
              </label>
              <input
                type="text"
                id="inp-1"
                onChange={(e) => { setName(e.target.value) }}
                value={name}
                className={classes.input + " form-control"}
                name="code"
                defaultValue={blog.name}
                required
              />
            </div>
            <div className="mb-5">
              <label htmlFor="inp-1" className="form-label">
                Descripction
              </label>
              <TextEditor
                        previousValue={editorState}
                        updatedValue={updatedValueCb}
                        height={300}
                    />             </div>
           <div className="mb-5">
                <label htmlFor="inp-2" className="form-label">
                        Upload Image*
                    </label>
                <input type="file"
                  onChange={(e)=>{setImage(e.target.files[0])}}
       accept="image/png, image/jpeg" />
                    
                </div>
            <div className="mb-4">
              <input
                type="submit"
                value="Update Blog"
                className="btn btn-success"
              />
            </div>
            
        </form>
        </div>
         )}
    </>
    
  )
}

editBlog.requireAuthAdmin = true;
editBlog.dashboard = true;

export default editBlog