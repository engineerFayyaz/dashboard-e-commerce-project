import { useEffect, useRef, useState } from "react";
import { MultiSelect } from "react-multi-select-component";
import { toast } from "react-toastify";
import useSWR from "swr";
import { fetchData, postData } from "~/lib/clientFunctions";
import FileUpload from "../../../components/fileUploadBanner/fileUpload";
import LoadingButton from "../../../components/Ui/Button";
import Spinner from "../../../components/Ui/Spinner";
import axios from "axios"
import classes from "~/components/ProductForm/productForm.module.css";
import { DiceFive } from "@styled-icons/fa-solid";

const ProductForm = () => {
  const url = `/api/product/create`;
  const { data, error } = useSWR(url, fetchData);

  const [Banner1, setBanner1] = useState([]);
  const [Banner2, setBanner2] = useState([]);
  const [Banner3, setBanner3] = useState([]);
  const [Banner4, setBanner4] = useState([]);
  const [Banner5, setBanner5] = useState([]);
let Link1=useRef("")
let Link2=useRef("")
let Link3=useRef("")
let Link4=useRef("")
let Link5=useRef("")




 

  const [GalleryLinks1, setGalleryLinks1] = useState([]);
  const [GalleryLinks2, setGalleryLinks2] = useState([]);
  const [GLinks1, setGLinks1] = useState([]);
  const [GLinks2, setGLinks2] = useState([]);

  const [galleryImage1, setGalleryImage1] = useState([]);
  const [galleryImage2, setGalleryImage2] = useState([]);


  const [buttonState, setButtonState] = useState("");
  const [resetImageInput, setResetImageInput] = useState("");


  const updateBanner1 = (files) => setBanner1(files);
  const updateBanner2 = (files) => setBanner2(files);
  const updateBanner3 = (files) => setBanner3(files);
  const updateBanner4 = (files) => setBanner4(files);
  const updateBanner5= (files) => setBanner5(files);

  const updateGalleryImage1 = (files) => setGalleryImage1(files);
  const updateGalleryImage2 = (files) => setGalleryImage2(files);
  const [bannersData,setBannersData]=useState({})

  useEffect(()=>{
   const getBanners=async()=>{
     let {data}=await axios.get(`${process.env.NEXT_PUBLIC_API}/store/homeBanner`)
     setBannersData(data)

   }
   getBanners()

  },[])

  const formHandler = async (e,banner,type,link,apiData) => {
    e.preventDefault();
    if (banner.length === 0 ) {
      if(link.length==0){
        return toast.warn("Please fil All required fields")
      }else{
        let links=[]
      if(typeof(link)=="string"){
        links.push(link)
      }else{
        links=link
      }
      setButtonState("loading");
      // const displayImg = await JSON.stringify(banner);
           
        let formData={
          Images:JSON.stringify(apiData.Images),
          type:type,
          link:JSON.stringify(links)
        }
        setResetImageInput("reset")
      await axios.post(`http://localhost:4200/api/store/homebanner/create`, formData)
        .then((status) => {
          status.data.success
            ? (toast.success("Banner Added Successfully"),
              form.reset())
            : toast.error("Something Went Wrong");
        })
        .catch((err) => {
          console.log(err);
          toast.error("Something Went Wrong");
        });
      setButtonState("");
      }
    }else{
      let links=[]
      if(typeof(link)=="string"){
        links.push(link)
      }else{
        links=link
      }
      setButtonState("loading");
      const displayImg = await JSON.stringify(banner);
           
        let formData={
          Images:displayImg,
          type:type,
          link:JSON.stringify(links)
        }
        setResetImageInput("reset")
      await axios.post(`http://localhost:4200/api/store/homebanner/create`, formData)
        .then((status) => {
          status.data.success
            ? (toast.success("Banner Added Successfully"),
              form.reset())
            : toast.error("Something Went Wrong");
        })
        .catch((err) => {
          console.log(err);
          toast.error("Something Went Wrong");
        });
      setButtonState("");
    }
   
  };

  if (error) return <div>failed to load</div>;
  if (!data) return <Spinner />;
  if (!data.success) return <div>Something Went Wrong...</div>;

 

  return (
    <>
      <h4 className="text-center pt-3 pb-5">Create/Edit Home Page Banners</h4>
        {Singleimage('Top Sale Banner','banner (1440px x 80px)*',updateBanner1,Banner1,"topsalebanner",Link1,bannersData?.topsalebanner)}
       {Slider("Top Slider Images","Gallery Images (1440px x 300px)*",updateGalleryImage1,galleryImage1,"topslider",bannersData?.topslider,GLinks1,setGLinks1,GalleryLinks1,setGalleryLinks1)}
        {Singleimage('Top Side Sale Banner','Top Side Sale Banner Images (300px x 300px)*',updateBanner2,Banner2,"sidesalebanner",Link2,bannersData?.sidesalebanner)}
        {Slider("Middle Slider","Gallery Images (1440px x 300px)*",updateGalleryImage2,galleryImage2,"middleslider",bannersData?.middleslider,GLinks2,setGLinks2,GalleryLinks2,setGalleryLinks2)}
        {Singleimage('First Section Banner','First Section Banner Images (1440px x 300px)*',updateBanner3,Banner3,"firstsectionbanner",Link3,bannersData?.firstsectionbanner)}
        {Singleimage('Second Section Banner','Second Section Banner Images (1440px x 300px)*',updateBanner4,Banner4,"secondsectionbanner",Link4,bannersData?.secondsectionbanner)}
        {Singleimage('Third Section Banner','Third Section Banner Images (1440px x 300px)*',updateBanner5,Banner5,"thirdsectionbanner",Link5,bannersData?.thirdsectionbanner)} 

    </>
  );






  function Singleimage(heading,label,callback,banner,type,link,apiData) {
    return (
        <form
        id="product_form"
        encType="multipart/form-data"
        onSubmit={(e)=>{formHandler(e,banner,type,link.current.value,apiData)}}
      >
      <div className="card mb-5 border-0 shadow">
    <div className="card-header bg-white py-3 fw-bold">{heading}</div>
    <div className="mb-5">
          <label htmlFor="inp-1" className="form-label">
            Link*
          </label>
          <input
            type="text"
            id="inp-1"
            className={classes.input + " form-control"}
            name="code"
            ref={link}
            defaultValue={apiData?.link.length>0?apiData?.link[0]:""}
            required
          />
        </div>
        <div className="card-body">
          <FileUpload
            accept=".jpg,.png,.jpeg"
            label={`${label}`}
            maxFileSizeInBytes={2000000}
            updateFilesCb={callback}
            resetCb={resetImageInput}
            preSelectedFiles={apiData?.Images}

          />
        </div>
      </div>
      <div className="my-4">
          <LoadingButton type="submit" text={`Add ${heading}`} state={buttonState} />
        </div>
      </form>

    );
  }



  function Slider(heading,label,callback,banner,type,apiData,link,setlink,galleryLinks,setGalleryLinks) {
    return (
        <form
       
        onSubmit={(e)=>{formHandler(e,banner,type,galleryLinks,apiData)}}
      >
      <div className="card mb-5 border-0 shadow">
    <div className="card-header bg-white py-3 fw-bold">{heading}</div>
    {
     galleryLinks?.map((data,i)=>{
       return(
        <div className="mb-5">
        <label htmlFor="inp-1" className="form-label">
          Link for {i+1} image
        </label>
        <div style={{display:"flex"}}>
        <input
          type="text"
          id="inp-1"
          className={classes.input + " form-control"}
          name="code"
          value={data}
          style={{width:"70%"}}
          disabled
        />
         <div style={{marginLeft:"20px"}}>
          <a 
           onClick={()=>{let a= galleryLinks?.filter((d)=>{return data!==d}); setGalleryLinks(a);setlink("")}}
          style={{backgroundColor:"yellow",padding:"5px 8px"}}>-</a></div>
         
          </div>
      
      </div>
       )
     })
    }
    <div className="mb-5">
          <label htmlFor="inp-1" className="form-label">
            Link*
          </label>
          <div style={{display:"flex"}}>
          <input
            type="text"
            id="inp-1"
            onChange={(e)=>{setlink(e.target.value)}}
            className={classes.input + " form-control"}
            style={{width:"70%"}}
            name="code"
            value={link}
          />
          <div style={{marginLeft:"20px"}}><a onClick={()=>{setGalleryLinks([...galleryLinks,link])}} style={{backgroundColor:"yellow",marginRight:"20px",padding:"5px 8px"}}>+</a>
          <button style={{backgroundColor:"yellow",padding:"5px 8px"}}>-</button></div>
          </div>
          
        </div>
        <div className="card-body">
          <FileUpload
            accept=".jpg,.png,.jpeg"
            label={label}
            multiple
            maxFileSizeInBytes={2000000}
            updateFilesCb={callback}
            preSelectedFiles={apiData?.Images}

          />
        </div>
      </div>
      <div className="my-4">
          <LoadingButton type="submit" text={`Add ${heading}`} state={buttonState} />
        </div>
      </form>

    );
  }


};
ProductForm.dashboard = true;

export default ProductForm;
