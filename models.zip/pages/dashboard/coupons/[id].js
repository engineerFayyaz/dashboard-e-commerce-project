import DefaultErrorPage from "next/error";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import useSWR from "swr";
import { fetchData, postData } from "~/lib/clientFunctions";
import classes from "../../../components/ProductForm/productForm.module.css";
import Spinner from "../../../components/Ui/Spinner/index";

const EditCoupon = () => {
  const router = useRouter();
  const url = `/api/coupons/edit?id=${router.query.id}`;
  const { data, error } = useSWR(router.query.id ? url : null, fetchData);

  const [couponData, setCouponData] = useState({});

  useEffect(() => {
    if (data && data.coupon) {
      setCouponData(data.coupon);
    }
  }, [data]);

  const submitHandler = async (e) => {
    e.preventDefault();
    try {
      const form = document.querySelector("#coupon_form");
      const formData = new FormData(form);
      const response = await postData("/api/coupons/edit", formData);
      response.success
        ? toast.success("Coupon Updated Successfully")
        : toast.error("Something Went Wrong");
    } catch (err) {
      console.log(err);
      toast.error("Something Went Wrong");
    }
  };

  return (
    <>
      {error ? (
        <DefaultErrorPage statusCode={500} />
      ) : !data ? (
        <Spinner />
      ) : !couponData._id ? (
        <DefaultErrorPage statusCode={404} />
      ) : (
        <div>
          <h4 className="text-center pt-3 pb-5">Edit Coupon</h4>
          <form id="coupon_form" onSubmit={submitHandler}>
            <input type="hidden" name="id" defaultValue={couponData._id} />
            <div className="mb-5">
              <label htmlFor="inp-1" className="form-label">
                Code*
              </label>
              <input
                type="text"
                id="inp-1"
                className={classes.input + " form-control"}
                name="code"
                defaultValue={couponData.code}
                required
              />
            </div>
            <div className="mb-4">
              <label htmlFor="inp-2" className="form-label">
                Amount in Percentage*
              </label>
              <input
                type="number"
                id="inp-2"
                step="0.1"
                className={classes.input + " form-control"}
                name="amount"
                defaultValue={couponData.amount}
                required
              />
            </div>
            <div className="row">
              <div className="col-12 col-sm-6">
                <div className="mb-4">
                  <label htmlFor="inp-3" className="form-label">
                    Active From*
                  </label>
                  <input
                    type="date"
                    id="inp-3"
                    className={classes.input + " form-control"}
                    name="active"
                    defaultValue={
                      new Date(couponData.active).toISOString().split("T")[0]
                    }
                    required
                  />
                </div>
              </div>
              <div className="col-12 col-sm-6">
                <div className="mb-4">
                  <label htmlFor="inp-4" className="form-label">
                    Will Expire*
                  </label>
                  <input
                    type="date"
                    id="inp-4"
                    className={classes.input + " form-control"}
                    name="expired"
                    defaultValue={
                      new Date(couponData.expired).toISOString().split("T")[0]
                    }
                    required
                  />
                </div>
              </div>
            </div>
            <div className="mb-4">
              <input
                type="submit"
                value="Update Coupon"
                className="btn btn-success"
              />
            </div>
          </form>
        </div>
      )}
    </>
  );
};

EditCoupon.requireAuthAdmin = true;
EditCoupon.dashboard = true;

export default EditCoupon;
