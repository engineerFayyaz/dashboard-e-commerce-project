import { Delete, NotepadEdit } from "@styled-icons/fluentui-system-regular";
import dynamic from "next/dynamic";
import Link from "next/link";
import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import useSWR from "swr";
import classes from "~/components/tableFilter/table.module.css";
import { deleteData, fetchData } from "~/lib/clientFunctions";

const DataTable = dynamic(() => import("react-data-table-component"));
const FilterComponent = dynamic(() => import("~/components/tableFilter"));
const GlobalModal = dynamic(() => import("~/components/Ui/Modal/modal"));
const Spinner = dynamic(() => import("~/components/Ui/Spinner"));

const Colors = () => {
  const url = `/api/colors`;
  const { data, error, mutate } = useSWR(url, fetchData);
  const [colorList, setColorList] = useState([]);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedColor, setSelectedColor] = useState("");

  useEffect(() => {
    if (data && data.colors) {
      setColorList(data.colors);
    }
  }, [data]);

  const openModal = (id) => {
    setSelectedColor(id);
    setIsOpen(true);
  };
  const closeModal = () => {
    setIsOpen(false);
  };

  const deleteColor = async () => {
    setIsOpen(false);
    await deleteData(`/api/colors?id=${selectedColor}`)
      .then((data) =>
        data.success
          ? (toast.success("Color Deleted Successfully"), mutate())
          : toast.error("Something Went Wrong"),
      )
      .catch((err) => {
        console.log(err);
        toast.error("Something Went Wrong");
      });
  };

  const [filterText, setFilterText] = React.useState("");
  const [resetPaginationToggle, setResetPaginationToggle] =
    React.useState(false);
  const filteredItems = colorList.filter(
    (item) =>
      item.name && item.name.toLowerCase().includes(filterText.toLowerCase()),
  );

  const subHeaderComponentMemo = React.useMemo(() => {
    const handleClear = () => {
      if (filterText) {
        setResetPaginationToggle(!resetPaginationToggle);
        setFilterText("");
      }
    };
    return (
      <FilterComponent
        onFilter={(e) => setFilterText(e.target.value)}
        onClear={handleClear}
        filterText={filterText}
      />
    );
  }, [filterText, resetPaginationToggle]);

  const customStyles = {
    rows: {
      style: {
        minHeight: "92px",
        fontSize: "15px",
      },
    },
    headCells: {
      style: {
        fontSize: "15px",
      },
    },
  };

  const columns = [
    {
      name: "Name",
      selector: (row) => row.name,
      sortable: true,
    },
    {
      name: "Value",
      selector: (row) => row.value,
    },
    {
      name: "Color",
      selector: (row) => (
        <div
          className={classes.color_viewer}
          style={{ backgroundColor: row.value }}
        />
      ),
    },
    {
      name: "Actions",
      selector: (row) => (
        <div>
          <div className={classes.button} onClick={() => openModal(row._id)}>
            <Delete width={30} height={30} title="DELETE" />
          </div>
          <Link href={`/dashboard/colors/${row._id}`}>
            <a>
              <div className={classes.button}>
                <NotepadEdit width={30} height={30} title="EDIT" />
              </div>
            </a>
          </Link>
        </div>
      ),
    },
  ];

  return (
    <>
      {error ? (
        <div className="text-center text-danger">failed to load</div>
      ) : !data ? (
        <Spinner />
      ) : (
        <div>
          <h4 className="text-center pt-3 pb-5">All Colors</h4>
          <div className={classes.container}>
            <DataTable
              columns={columns}
              data={filteredItems}
              pagination
              paginationResetDefaultPage={resetPaginationToggle}
              subHeader
              subHeaderComponent={subHeaderComponentMemo}
              persistTableHead
              customStyles={customStyles}
            />
          </div>
          <GlobalModal
            isOpen={isOpen}
            handleCloseModal={closeModal}
            small={true}
          >
            <div className={classes.modal_icon}>
              <Delete width={100} height={100} />
              <p>Are you sure, you want to delete?</p>
              <div>
                <button
                  className={classes.danger_button}
                  onClick={() => deleteColor()}
                >
                  Delete
                </button>
                <button
                  className={classes.success_button}
                  onClick={() => closeModal()}
                >
                  Cancel
                </button>
              </div>
            </div>
          </GlobalModal>
        </div>
      )}
    </>
  );
};

Colors.requireAuthAdmin = true;
Colors.dashboard = true;

export default Colors;
