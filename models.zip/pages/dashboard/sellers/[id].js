import dynamic from "next/dynamic";
import DefaultErrorPage from "next/error";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/router";
import { useEffect, useRef, useState } from "react";
import { useSelector } from "react-redux";
import useSWR from "swr";
import { fetchData, postData } from "~/lib/clientFunctions";
import classes from "~/styles/orderDetails.module.css";

const Invoice = dynamic(() => import("~/components/Invoice"));
const Spinner = dynamic(() => import("~/components/Ui/Spinner"));

const ViewOrder = () => {
  const router = useRouter();
  const invoiceRef = useRef(null);
  const url = `${process.env.NEXT_PUBLIC_API}/users/get/seller/products?id=${router.query.id}`;
  const { data, error } = useSWR(router.query.id ? url : null, fetchData);
  const { sellerData, sellererror } = useSWR(router.query.id ? product_url : null, fetchData);
  const product_url = `${process.env.NEXT_PUBLIC_API}/users/get/seller/products?id=${router.query.id}`;
  let Sellerdata = fetchData(product_url);
  const [orderData, setOrderData] = useState({});
  const [userData, setUserData] = useState({});
  const [SellerdataEffect, setSellerdataEffect] = useState({});
  const [sellerOrders, setSellerOrders] = useState({});
    
  useEffect(() => {

    if (data && data.user && data.user.orders) {
      setOrderData(data.user.orders);
    }
    if (data && data.user) {
        setUserData(data.user);
      }
      if(data && data.products){
        setSellerdataEffect(data.products )
      }
      if(data && data.orderObject){
        setSellerOrders(data.orderObject)
      }
      

  }, [data]);


  const settings = useSelector((state) => state.settings);
  const currencySymbol = settings.settingsData.currency.symbol;

  const decimalBalance = (num) => Math.round(num * 10) / 10;

  const printInvoice = async () => {
    const { printDocument } = await import("~/lib/clientFunctions");
    invoiceRef.current.style.display = "block";
    await printDocument(invoiceRef.current, `Invoice #${orderData.orderId}`);
    invoiceRef.current.style.display = "none";
  };

  const handleOrderStatus = (e,order_id , p_id , u_id , status) => {
    const objectData = {
        "order_id": order_id,
        "user_id": u_id,
        "pid": p_id,
        "status": e.target.value
    }
    const setOrder = postData(`${process.env.NEXT_PUBLIC_API}/store/addstatus/order` , objectData)
  }

  const handlePaymentStatus = async (e,order_id , u_id , p_id , status) => {
    console.log(e.target)
    const objectData = {
        "order_id": order_id,
        "user_id": u_id,
        "pid": p_id,
        "status": e.target.value
    }
    const setOrder = postData(`${process.env.NEXT_PUBLIC_API}/store/addpaymentstatus/order` , objectData)
  };

  console.log(SellerdataEffect ,'aaaa')
  return (
    <>
      {error ? (
        <DefaultErrorPage statusCode={500} />
      ) : !data ? (
        <Spinner />
      ) : !data.success ? (
        <DefaultErrorPage statusCode={404} />
      ) : (
        <div>
          <div className="card mb-4">
            <div className="card-body">
              <div className="d-sm-flex align-items-center justify-content-between">
                <h5 className="mb-0">Seller Profile</h5>
               
              </div>
              <hr/>
              <div className="table-responsive">
                  <table className="table table-bordered">
                    <thead>
                    <th>Seller Name</th>
                    <th>Seller Email</th>
                    <th>Seller Phone</th>
                    <th>CNIC</th>
                    <th>Address</th>
                    <th style={{'text-align': 'center'}}>Bank Detail</th>
                    </thead>
                   <tbody>
                   <td>{userData.firstname} {userData.lastname}</td>
                   <td>{userData.email}</td>
                   <td>{userData.phone}</td>
                   <td>{userData.cnic}</td>
                   <td>{userData.address}</td>
                   <td><table className="table table-bordered">
                    <thead>
                        <tr>
                        <th>Name</th>
                        <th>Bank Account</th>
                        <th>Branch</th>
                        </tr>
                    </thead>
                    
                    <tbody>
                    {userData.bankDetails && userData.bankDetails.map((bank, idx) => (
                        <tr key={idx}>
                        <td>{bank.name}</td>
                        <td>{bank.accountnumber}</td>
                        <td>{bank.branch}</td>
                        </tr>))}
                    </tbody>
                    </table>
                </td>
                   </tbody>
                    </table>
                    </div>
            </div>
          </div>
          <div className="card mb-4">
            <div className="card-body">
              <div className="d-sm-flex align-items-center justify-content-between">
                <h5 className="mb-0">Seller Products</h5>
                <div className="table-responsive">
                  <table className="table table-bordered">
                  <thead>
                        <tr>
                        <th>Product Name</th>
                        <th>Margin Price </th>
                        <th> Price </th>
                        <th>Quantity</th>
                        </tr>
                    </thead>
                    {SellerdataEffect && SellerdataEffect.length>0 && SellerdataEffect.map((prod, idx) => (
                        <tr key={idx}>
                        <td>{prod.name}</td>
                        <td>{prod.margin_price}</td>
                        <td>{prod.bideprice}</td>
                        <td>{prod.bidquantity}</td>
                        </tr>))}
                    </table>
                    </div>
              </div>
            </div>
          </div>

          <div className="card mb-4">
            <div className="card-body">
              <div className="d-sm-flex align-items-center justify-content-between">
                <h5 className="mb-0">Orders List</h5>
                <hr></hr>
                <div className="table-responsive">
                <table className="table table-bordered">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Product Name</th>
                        <th scope="col">Image</th>
                        
                        <th scope="col">Quantity</th>
                        <th scope="col">Order Status</th>
                        <th scope="col">Payment Status</th>
                        <th scope="col">Price</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sellerOrders && sellerOrders.length>0 && sellerOrders.map((products, idx) => (
                        <tr key={idx}>
                          <th scope="row">{idx + 1}</th>
                          <td>{products && products.product.name}</td>
                          <td>
                            <img
                              src={products.product && products.product.image[0].url}
                              width={50}
                              height={50}
                              alt={products && products.product.name}
                            />
                          </td>
                          <td>{products.product.quantity}</td>
                          
                          <td>
                          <div className="dropdown">
          <select
          defaultValue={products.product.order_status}
            onChange={(e) => handleOrderStatus(e,products.order_id , products.product._id , products.product.seller_id , e.target.value)}
            
          >
            <option value="In Progress">Accepted</option>
            <option value="Dispatched">Dispatched To BabaBoota</option>
            {/* <option value="cancel">Refused/Cancel</option> */}
            <option value="Delivered">Dispatched To Customer</option>
            <option value="Completed">Delivered</option>
            <option value="Returned">Returned</option>
          </select>
        </div>
                          </td>
                          <td>
                          <select
          defaultValue={products.product.payment_status}
            onChange={(e) => handlePaymentStatus(e,products.order_id , products.product.seller_id , products.product._id , "In Progress")}
            
          >
            <option value="pending">Pending</option>
            <option value="inprogress">In Progress</option>
            <option value="accept">Accept</option>
            <option></option>
          </select>
                          </td>
                          <td>{products && products.product.price}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  </div>
              </div>
            </div>
          </div>
          <div>
          
            
          </div>
        </div>
      )}
    </>
  );
};

ViewOrder.requireAuthAdmin = true;
ViewOrder.dashboard = true;

export default ViewOrder;
