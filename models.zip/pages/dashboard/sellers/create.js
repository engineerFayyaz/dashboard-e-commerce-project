import { toast } from "react-toastify";
import classes from "~/components/ProductForm/productForm.module.css";
import { postData } from "~/lib/clientFunctions";
const url = "http://localhost:4200/api";
const NewCoupon = () => {
  const submitHandler = async (e) => {
    e.preventDefault();
    try {
      const form = document.querySelector("#seller_form");
      const formData = new FormData(form);
      const response = await postData(`${url}/users/create/seller`, formData);
      response.success
        ? (toast.success("Seller Added Successfully"), form.reset())
        : toast.error("Something Went Wrong");
    } catch (err) {
      console.log(err);
      toast.error("Something Went Wrong");
    }
  };
  return (
    <>
      <h4 className="text-center pt-3 pb-5">Create Seller</h4>
      <form id="seller_form" onSubmit={submitHandler}>
        <div className="row">
          <div className="col-12 col-sm-4">
            <div className="mb-4">
              <label htmlFor="inp-3" className="form-label">
                Seller First Name
              </label>
              <input
                type="text"
                id="inp-3"
                placeholder="Seller First Name"
                className={classes.input + " form-control"}
                name="firstname"
                required
              />
            </div>
          </div>
          <div className="col-12 col-sm-4">
            <div className="mb-4">
              <label htmlFor="inp-3" className="form-label">
                Seller Last Name
              </label>
              <input
                type="text"
                id="inp-3"
                placeholder="Seller Last Name"
                className={classes.input + " form-control"}
                name="lastname"
                required
              />
            </div>
          </div>
          <div className="col-12 col-sm-4">
            <div className="mb-4">
              <label htmlFor="inp-4" className="form-label">
                Seller Email
              </label>
              <input
                type="email"
                id="inp-4"
                placeholder="Email Address"
                className={classes.input + " form-control"}
                name="email"
                required
              />
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-12 col-sm-6">
            <div className="mb-4">
              <label htmlFor="inp-3" className="form-label">
                Seller Phone
              </label>
              <input
                type="text"
                id="inp-3"
                placeholder="Seller Phone"
                className={classes.input + " form-control"}
                name="phone"
                required
              />
            </div>
          </div>
          <div className="col-12 col-sm-6">
            <div className="mb-4">
              <label htmlFor="inp-4" className="form-label">
                Seller Address
              </label>
              <input
                type="text"
                id="inp-4"
                placeholder="Seller Address"
                className={classes.input + " form-control"}
                name="address"
                required
              />
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-12 col-sm-6">
            <div className="mb-4">
              <label htmlFor="inp-3" className="form-label">
                Seller Cnic
              </label>
              <input
                type="text"
                id="inp-3"
                placeholder="Seller Cnic"
                className={classes.input + " form-control"}
                name="cnic"
                required
              />
            </div>
          </div>
          <div className="col-12 col-sm-6">
            <div className="mb-4">
              <label htmlFor="inp-4" className="form-label">
                Seller Postal Address
              </label>
              <input
                type="text"
                id="inp-4"
                placeholder="Seller Postal Address"
                className={classes.input + " form-control"}
                name="sellerpostaladdress"
                required
              />
            </div>
          </div>
        </div>
        <div className="mb-4">
          <input type="submit" value="Add Seller" className="btn btn-success" />
        </div>
      </form>
    </>
  );
};

NewCoupon.requireAuthAdmin = true;
NewCoupon.dashboard = true;

export default NewCoupon;
