import dynamic from "next/dynamic";
import DefaultErrorPage from "next/error";
import { useEffect, useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import useSWR from "swr";
import { fetchData, postData } from "~/lib/clientFunctions";

const Spinner = dynamic(() => import("~/components/Ui/Spinner"));
const TextEditor = dynamic(() => import("~/components/TextEditor"));
const LoadingButton = dynamic(() => import("~/components/Ui/Button"));

const FaqPageSetup = () => {
  const url = `/api/page`;
  const { data, error } = useSWR(url, fetchData);

  const [editorState, setEditorState] = useState("");
  const [buttonState, setButtonState] = useState("");

  useEffect(() => {
    if (data && data.page && data.page.faqPage) {
      setEditorState(data.page.faqPage.content);
    }
  }, [data]);

  const updatedValueCb = (data) => {
    setEditorState(data);
  };

  const handleSubmit = async () => {
    setButtonState("loading");
    try {
      const response = await postData(`/api/page?scope=faq`, {
        content: editorState,
      });
      response.success
        ? toast.success("Page updated successfully!")
        : toast.error("Something went wrong 500");
    } catch (err) {
      console.log(err);
      toast.error("Something went wrong ", err.message);
    }
    setButtonState("");
  };

  return (
    <>
      {error ? (
        <DefaultErrorPage statusCode={500} />
      ) : !data ? (
        <Spinner />
      ) : (
        <div>
          <div className="py-3">
            <TextEditor
              previousValue={editorState}
              updatedValue={updatedValueCb}
            />
          </div>
          <div className="py-3">
            <LoadingButton
              text={"Update"}
              state={buttonState}
              clickEvent={handleSubmit}
            />
          </div>
          <ToastContainer />
        </div>
      )}
    </>
  );
};

FaqPageSetup.requireAuthAdmin = true;
FaqPageSetup.dashboard = true;

export default FaqPageSetup;
