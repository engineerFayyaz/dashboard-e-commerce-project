import dynamic from "next/dynamic";
import { useRouter } from "next/router";
import { useEffect, useRef, useState } from "react";
import { toast } from "react-toastify";
import classes from "~/components/ProductForm/productForm.module.css";
import { postData } from "~/lib/clientFunctions";
import axios from "axios";

const FileUpload = dynamic(() => import("~/components/FileUpload/fileUpload"));
const LoadingButton = dynamic(() => import("~/components/Ui/Button"));

const ImportCategory = (props) => {
  const [updateProductImage, setUpdateProductImage] = useState([]);
  const [buttonState, setButtonState] = useState("");
  const name = useRef(null);
  const router = useRouter();


    const handleNewFileUpload = async (e) => {
        const { files: newFiles } = e.target;
        console.log(newFiles[0])
        if (newFiles.length) {
            const body = new FormData();
            // console.log("file", image)
            body.append("file", newFiles[0]);
              // post the image directly to the s3 bucket
              let fileName = await axios({
                method: "post",
                url: `${process.env.NEXT_PUBLIC_API}/dashboard/readfile`,
                headers: {
                  "Content-Type": "multipart/form-data",
                },
                data: body,
              });
        }
    }

  const redirectToPage = (url, waitingTime) => {
    setTimeout(() => {
      router.push(url);
    }, waitingTime);
  };
  const useEffect = () => {
    console.log(updateProductImage)
  }
  const submitHandler = async (e) => {
    e.preventDefault();
    try {
       console.log(updateProductImage)
    } catch (err) {
      setButtonState("");
      toast.error(`Something Went Wrong ${err.message}`);
    }
  };
  return (
    <>
      <h4 className="text-center pt-3 pb-5">Upload File</h4>
      <form encType="multipart/form-data" onSubmit={submitHandler}>
        
        <div className="mb-4 pt-2">
       <input type="file" onChange={handleNewFileUpload}/>
        </div>
       
      </form>
    </>
  );
};
ImportCategory.dashboard =true;
export default ImportCategory;
