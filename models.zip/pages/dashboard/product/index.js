import { Delete, NotepadEdit } from "@styled-icons/fluentui-system-regular";
import dynamic from "next/dynamic";
import Image from "next/image";
import Link from "next/link";
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import useSWR from "swr";
import classes from "~/components/tableFilter/table.module.css";
import { deleteData, fetchData,postData } from "~/lib/clientFunctions";

const DataTable = dynamic(() => import("react-data-table-component"));
const FilterComponent = dynamic(() => import("~/components/tableFilter"));
const GlobalModal = dynamic(() => import("~/components/Ui/Modal/modal"));
const Spinner = dynamic(() => import("~/components/Ui/Spinner"));

const ProductList = () => {
  const url = `/api/product`;
  const { data, error, mutate } = useSWR(url, fetchData);
  const [productList, setProductList] = useState([]);
  useEffect(() => {
    if (data && data.product) {
      setProductList(data.product);
    }
  }, [data]);

  const [isOpen, setIsOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState("");

  const settings = useSelector((state) => state.settings);
  const currencySymbol = settings.settingsData.currency.symbol;

  const openModal = (id) => {
    setSelectedProduct(id);
    setIsOpen(true);
  };
  const closeModal = () => {
    setIsOpen(false);
  };

  const deleteProduct = async () => {
    setIsOpen(false);
    await deleteData(`/api/product/delete/${selectedProduct}`)
      .then((data) =>
        data.success
          ? (toast.success("Product Deleted Successfully"), mutate())
          : toast.error("Something Went Wrong"),
      )
      .catch((err) => {
        console.log(err);
        toast.error("Something Went Wrong");
      });
  };

  const newArrivalPro = async (status,id) => {
    await postData(`${process.env.NEXT_PUBLIC_API}/dashboard/productnewupdate`, {id,status:!status})
    .then((status) =>
      status.success
        ? toast.success("Product Updated Successfully")
        : toast.error("Something Went Wrong"),
    )
    .catch((err) => {
      console.log(err);
      toast.error(`Something Went Wrong ${err.message}`);
    });
   console.log(id,status)
   mutate()
  };

  const [filterText, setFilterText] = React.useState("");
  const [resetPaginationToggle, setResetPaginationToggle] =
    React.useState(false);
  const filteredItems = productList.filter(
    (item) =>
      item.name && item.name.toLowerCase().includes(filterText.toLowerCase()),
  );

  const subHeaderComponentMemo = React.useMemo(() => {
    const handleClear = () => {
      if (filterText) {
        setResetPaginationToggle(!resetPaginationToggle);
        setFilterText("");
      }
    };
    return (
      <FilterComponent
        onFilter={(e) => setFilterText(e.target.value)}
        onClear={handleClear}
        filterText={filterText}
      />
    );
  }, [filterText, resetPaginationToggle]);

  const columns = [
    {
      name: "Product Id",
      selector: (row) => row.productId,
    },
    {
      name: "Name",
      selector: (row) => row.name,
      sortable: true,
    },
    {
      name: "image",
      selector: (row) => (
        <Image src={row.image[0].url} alt={data.name} width={80} height={80} />
      ),
    },
    {
      name: "Product Type",
      selector: (row) => row.type.toUpperCase(),
      sortable: true,
    },
    {
      name: "price",
      selector: (row) => currencySymbol + row.price,
      sortable: true,
    },
    {
      name: "New Arrival",
      selector: (row) => (
        <div>
           <div onClick={()=>{newArrivalPro(row.new,row._id)}} className="form-check form-switch">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="inp-110"
                    name="new_product"
                    defaultChecked={row.new}
                  />
                  
                </div>
        </div>
      ),
    },
    {
      name: "Action",
      selector: (row) => (
        <div>
          <div className={classes.button} onClick={() => openModal(row._id)}>
            <Delete width={30} height={30} title="DELETE" />
          </div>
          <Link href={`/dashboard/product/${row.slug}`}>
            <a>
              <div className={classes.button}>
                <NotepadEdit width={30} height={30} title="EDIT" />
              </div>
            </a>
          </Link>
        </div>
      ),
    },
  ];

  const customStyles = {
    rows: {
      style: {
        minHeight: "92px",
        fontSize: "15px",
      },
    },
    headCells: {
      style: {
        fontSize: "15px",
      },
    },
  };

  return (
    <>
      {error ? (
        <div className="text-center text-danger">failed to load</div>
      ) : !data ? (
        <Spinner />
      ) : (
        <div>
          <h4 className="text-center pt-3 pb-5">Products</h4>
          <div className={classes.container}>
            <DataTable
              columns={columns}
              data={filteredItems}
              pagination
              paginationResetDefaultPage={resetPaginationToggle}
              subHeader
              subHeaderComponent={subHeaderComponentMemo}
              persistTableHead
              customStyles={customStyles}
            />
            <GlobalModal
              isOpen={isOpen}
              handleCloseModal={closeModal}
              small={true}
            >
              <div className={classes.modal_icon}>
                <Delete width={100} height={100} />
                <p>Are you sure, you want to delete?</p>
                <div>
                  <button
                    className={classes.danger_button}
                    onClick={() => deleteProduct()}
                  >
                    Delete
                  </button>
                  <button
                    className={classes.success_button}
                    onClick={() => closeModal()}
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </GlobalModal>
          </div>
        </div>
      )}
    </>
  );
};

ProductList.requireAuthAdmin = true;
ProductList.dashboard = true;

export default ProductList;
