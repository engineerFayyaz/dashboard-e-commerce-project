import { getCsrfToken, getSession, signIn } from "next-auth/client";
import Link from "next/link";
import { useRouter } from "next/router";
import { useSelector } from "react-redux";
import Error500 from "~/components/error/500";
import HeadData from "~/components/Head";
import { appUrl, fetchData, setSettingsData } from "~/lib/clientFunctions";
import { wrapper } from "~/redux/store";
import classes from "~/styles/signin.module.css";
export default function SignIn({ authCsrfToken, srvError }) {
  const { error } = useRouter().query;
  const errors = {
    Signin: "Try signing with a different account.",
    OAuthSignin: "Try signing with a different account.",
    OAuthCallback: "Try signing with a different account.",
    OAuthCreateAccount: "Try signing with a different account.",
    EmailCreateAccount: "Try signing with a different account.",
    Callback: "Try signing with a different account.",
    OAuthAccountNotLinked:
      "To confirm your identity, sign in with the same account you used originally.",
    EmailSignin: "Check your email address.",
    CredentialsSignin:
      "Sign in failed. Check the details you provided are correct.",
    default: "Unable to sign in.",
  };
  const SignInError = ({ error }) => {
    const errorMessage = error && (errors[error] ?? errors.default);
    return <div className="alert alert-danger">{errorMessage}</div>;
  };

  return (
    <>
      {srvError ? (
        <Error500 />
      ) : (
        <>
          <HeadData title="Sign in" />
          <div className={classes.container}>
            <div className={classes.card}>
              <h1>SIGN IN</h1>
              {error && <SignInError error={error} />}
              <form
                action="/api/auth/callback/credentials"
                method="POST"
                className={classes.form}
              >
                <input
                  name="csrfToken"
                  type="hidden"
                  defaultValue={authCsrfToken}
                />
                <input
                  type="email"
                  className="form-control"
                  id="email"
                  name="username"
                  placeholder="Email"
                  required
                />
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  name="password"
                  placeholder="Password"
                  required
                />
                <div className={classes.reset_link}>
                  <Link href="/reset">
                    <a>Forget your password?</a>
                  </Link>
                </div>
                <button type="submit">SIGN IN</button>
              </form>
              
            </div>
          </div>
        </>
      )}
    </>
  );
}

SignIn.getInitialProps = wrapper.getInitialPageProps(
  (store) => async (context) => {
    try {
      const { origin } = appUrl(context.req);
      const response = await fetchData(`${origin}/api/home/settings`);
      setSettingsData(store, response);
      const { req, res } = context;
      const session = await getSession({ req });
      if (session && res && session.user) {
        res.writeHead(302, {
          Location: "/dashboard",
        });
        res.end();
        return;
      }

      return {
        session: undefined,
        authCsrfToken: await getCsrfToken(context),
      };
    } catch (err) {
      console.log(err);
      return {
        srvError: true,
      };
    }
  },
);

SignIn.footer = false;
