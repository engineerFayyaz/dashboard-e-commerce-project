import Error404 from "~/components/error/404";

export default function Custom404() {
  return <Error404 />;
}

Custom404.hasError = true;
