import Error500 from "~/components/error/500";

export default function Custom500() {
  return <Error500 />;
}

Custom500.hasError = true;
