import Link from "next/link";
import classes from "./banner.module.css";

const Banner = (props) => {
  if (!props.banner) return null;

  return (
    <div className={classes.content_container}>
      <div className="col-12">
        <div
          className={classes.banner}
          style={{ backgroundImage: `url(${props.banner.image[0].url})` }}
        >
          <div className={classes.content}>
            <h2 className={classes.heading}>{props.banner.title}</h2>
            <h4 className={classes.subheading}>{props.banner.subTitle}</h4>
            <p className={classes.body}>{props.banner.description}</p>
            <Link href={props.banner.url}>
              <a className={classes.button}>SHOP NOW</a>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Banner;
