import { BoxSeam, CardText, PeopleFill } from "@styled-icons/bootstrap";
import {
  CategoryAlt,
  ColorFill,
  CubeAlt,
  User,
  tex
} from "@styled-icons/boxicons-regular";
import {
  Dashboard,
  Email,
  LocalShipping,
  Settings,
  SettingsSuggest,
} from "@styled-icons/material";
import Link from "next/link";
import React, { useState } from "react";
import classes from "./menu.module.css";

const DashboardMenu = (props) => {
  const isOpen = props.menuState;
  const menuData = [
    {
      name: "Dashboard",
      icon: <Dashboard width={20} height={20} />,
      subMenu: [
        {
          name: "Dashboard",
          url: "/dashboard",
        },
      ],
    },
    {
      name: "Sellers",
      icon: <User width={20} height={20} />,
      subMenu: [
        {
          name: "All Sellers",
          url: "/dashboard/sellers",
        },
        {
          name: "Add New Seller",
          url: "/dashboard/sellers/create",
        },
      ],
    },
    {
      name: "Products",
      icon: <CubeAlt width={20} height={20} />,
      subMenu: [
        {
          name: "All Products",
          url: "/dashboard/product",
        },
        {
          name: "Import Product",
          url: "/dashboard/product/import",
        },
        {
          name: "Add New Product",
          url: "/dashboard/product/create",
        },
      ],
    },
    {
      name: "Orders",
      icon: <BoxSeam width={20} height={20} />,
      subMenu: [
        {
          name: "All Orders",
          url: "/dashboard/orders",
        },
      ],
    },
    {
      name: "Home Banners",
      icon: <CategoryAlt width={20} height={20} />,
      subMenu: [
        {
          name: "Add/Edit Home Banners",
          url: "/dashboard/banners",
        },
      ],
    },
    {
      name: "Categories",
      icon: <CategoryAlt width={20} height={20} />,
      subMenu: [
        {
          name: "Category List",
          url: "/dashboard/categories",
        },
        {
          name: "Add New Category",
          url: "/dashboard/categories/create",
        },
        {
          name: "Subcategory List",
          url: "/dashboard/categories/subcategories",
        },
        {
          name: "Add New Subcategory",
          url: "/dashboard/categories/subcategories/create",
        },
      ],
    },
    {
      name: "Coupons",
      icon: <CardText width={20} height={20} />,
      subMenu: [
        {
          name: "All Coupons",
          url: "/dashboard/coupons",
        },
        {
          name: "Add New Coupon",
          url: "/dashboard/coupons/create",
        },
      ],
    },
    {
      name: "Blogs",
      icon: <CardText width={20} height={20} />,
      subMenu: [
        {
          name: "All Blogs",
          url: "/dashboard/blogs",
        },
        {
          name: "Add New Blog",
          url: "/dashboard/blogs/create",
        },
       
      ],
    },
    {
      name: "Colors",
      icon: <ColorFill width={20} height={20} />,
      subMenu: [
        {
          name: "All Colors",
          url: "/dashboard/colors",
        },
        {
          name: "Add New Color",
          url: "/dashboard/colors/create",
        },
      ],
    },
    {
      name: "Attributes",
      icon: <SettingsSuggest width={20} height={20} />,
      subMenu: [
        {
          name: "All Attributes",
          url: "/dashboard/attributes",
        },
        {
          name: "Add New Attribute",
          url: "/dashboard/attributes/create",
        },
      ],
    },
    // {
    //   name: "Shipping Charges",
    //   icon: <LocalShipping width={20} height={20} />,
    //   subMenu: [
    //     {
    //       name: "Modify Shipping Charges",
    //       url: "/dashboard/shipping",
    //     },
    //   ],
    // },
    // {
    //   name: "Subscribers",
    //   icon: <Email width={20} height={20} />,
    //   subMenu: [
    //     {
    //       name: "Subscriber List",
    //       url: "/dashboard/subscribers",
    //     },
    //   ],
    // },
    {
      name: "Customers",
      icon: <PeopleFill width={20} height={20} />,
      subMenu: [
        {
          name: "Customer List",
          url: "/dashboard/users",
        },
      ],
    },
    {
      name: "Settings",
      icon: <Settings width={20} height={20} />,
      subMenu: [
        {
          name: "General Settings",
          url: "/dashboard/settings",
        },
        {
          name: "Layout Settings",
          url: "/dashboard/settings/layout",
        },
        {
          name: "Graphics Content",
          url: "/dashboard/settings/graphics",
        },
        {
          name: "Seo",
          url: "/dashboard/settings/seo",
        },
        {
          name: "Script",
          url: "/dashboard/settings/script",
        },
        {
          name: "Payment Gateway",
          url: "/dashboard/settings/gateway",
        },
        {
          name: "Social Media Login",
          url: "/dashboard/settings/login",
        },
      ],
    },
    {
      name: "Page Settings",
      icon: <Settings width={20} height={20} />,
      subMenu: [
        {
          name: "Home Page",
          url: "/dashboard/page/home",
        },
        {
          name: "About Us",
          url: "/dashboard/page/about",
        },
        {
          name: "Privacy Policy",
          url: "/dashboard/page/privacy",
        },
        {
          name: "Terms & Conditions",
          url: "/dashboard/page/terms",
        },
        {
          name: "Return Policy",
          url: "/dashboard/page/return",
        },
        {
          name: "FAQ",
          url: "/dashboard/page/faq",
        },
      ],
    },
  ];

  const [clicked, setClicked] = useState("0");

  const handleClick = (index) => {
    if (clicked === index) {
      return setClicked("0");
    }
    setClicked(index);
  };

  return (
    <div className={`${classes.menu} ${isOpen ? classes.show : classes.hide}`}>
      <div className={classes.sidebar_inner}>
        <div className="flex-shrink-0">
          <ul className={classes.list_auto}>
            {menuData.map((menu, index) => (
              <li className={classes.menu_list} key={index}>
                <button
                  className={clicked === index ? classes.button_active : ""}
                  onClick={() => handleClick(index)}
                >
                  {menu.icon} {menu.name}
                </button>
                <div
                  className={
                    clicked === index ? classes.expand : classes.collapse
                  }
                >
                  <ul className={classes.collapse_item}>
                    {menu.subMenu.map((subMenu, index) => (
                      <li key={index} className={classes.sublist}>
                        <Link href={subMenu.url}>
                          <a className="link-dark category-btn-ind">
                            {subMenu.name}
                          </a>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default React.memo(DashboardMenu);
