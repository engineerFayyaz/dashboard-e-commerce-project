import Image from "next/image";
import Link from "next/link";
import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import classes from "./header.module.css";

function Header(props) {
  if (!props.carousel) return null;

  return (
    <div className="col-12 custom-carousel">
      <div
        className={classes.header}
        style={{ backgroundImage: `url(${props.carousel.background[0].url})` }}
      >
        <Carousel
          showArrows={false}
          showThumbs={false}
          showIndicators={true}
          emulateTouch={true}
          showStatus={false}
          infiniteLoop={true}
          // autoPlay={false}
          // stopOnHover={true}
          // interval={8000}
          // transitionTime={500}
        >
          {props.carousel.carouselData &&
            props.carousel.carouselData.map((item) => (
              <div key={item.id}>
                <div className={classes.Header_container}>
                  <div className={classes.img_content}>
                    <div className={classes.img_container}>
                      <Image
                        src={item.image[0].url}
                        width={750}
                        height={750}
                        alt={item.title}
                      />
                    </div>
                  </div>
                  <div className={classes.content}>
                    <div className={classes.body}>
                      <h1>{item.title}</h1>
                      <h4>{item.subTitle}</h4>
                      <p>{item.description}</p>
                      <Link href={item.url} passHref>
                        <a>SHOP NOW</a>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            ))}
        </Carousel>
      </div>
    </div>
  );
}

export default Header;
