import { useSession } from "next-auth/client";
import Error403 from "../error/403";

const CheckAuth = ({ auth, authAdmin, children }) => {
  const [session, loading] = useSession();
  return (
    <>
      {auth && !loading && !session ? (
        <Error403 />
      ) : authAdmin && !loading && (!session || !session.user.a) ? (
        <Error403 />
      ) : (
        <>{children}</>
      )}
    </>
  );
};

export default CheckAuth;
