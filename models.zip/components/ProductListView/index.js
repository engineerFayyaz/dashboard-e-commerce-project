import { LeftArrow, RightArrow } from "@styled-icons/boxicons-regular";
import "keen-slider/keen-slider.min.css";
import { useKeenSlider } from "keen-slider/react";
import { useState } from "react";
import ProductCard from "./productCard";

function ProductList(props) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [sliderRef, slider] = useKeenSlider({
    spacing: 10,
    slidesPerView: 1,
    centered: false,
    loop: false,
    mode: "snap",
    breakpoints: {
      "(min-width: 320px)": {
        slidesPerView: 1,
      },
      "(min-width: 560px)": {
        slidesPerView: 2,
      },
      "(min-width: 991px)": {
        slidesPerView: 3,
      },
      "(min-width: 1200px)": {
        slidesPerView: 4,
      },
      "(min-width: 1600px)": {
        slidesPerView: 5,
      },
    },
    initial: 0,
    slideChanged(s) {
      setCurrentSlide(s.details().relativeSlide);
    },
  });

  if (!props.item || !props.item.length) {
    return null;
  }

  return (
    <div className="content_container">
      <div className="custom_container">
        <h2 className="content_heading">{props.title}</h2>
        <div className="navigation-wrapper">
          <div ref={sliderRef} className="keen-slider">
            {props.item.map((item) => (
              <div className="keen-slider__slide" key={item._id}>
                <ProductCard data={item} />
              </div>
            ))}
          </div>
          {slider && (
            <>
              <ArrowLeft
                onClick={(e) => e.stopPropagation() || slider.prev()}
                disabled={currentSlide === 0}
              />
              <ArrowRight
                onClick={(e) => e.stopPropagation() || slider.next()}
                disabled={currentSlide === slider.details().size - 1}
              />
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function ArrowLeft(props) {
  const disabled = props.disabled ? " arrow--disabled" : "";
  return (
    <div onClick={props.onClick} className={"arrow arrow--left" + disabled}>
      <LeftArrow width={15} height={15} />
    </div>
  );
}

function ArrowRight(props) {
  const disabled = props.disabled ? " arrow--disabled" : "";
  return (
    <div onClick={props.onClick} className={"arrow arrow--right" + disabled}>
      <RightArrow width={15} height={15} />
    </div>
  );
}

export default ProductList;
