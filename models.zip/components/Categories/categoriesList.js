import "keen-slider/keen-slider.min.css";
import { useKeenSlider } from "keen-slider/react";
import Category from "./categories";

function CategoryList(props) {
  const [sliderRefB] = useKeenSlider({
    slidesPerView: 1,
    loop: false,
    mode: "snap",
    breakpoints: {
      "(min-width: 0px)": {
        slidesPerView: 1,
      },
      "(min-width: 424px)": {
        slidesPerView: 2,
      },
      "(min-width: 560px)": {
        slidesPerView: 3,
      },
      "(min-width: 991px)": {
        slidesPerView: 4,
      },
      "(min-width: 1200px)": {
        slidesPerView: 6,
      },
    },
  });

  if (!props.categoryList || !props.categoryList.length) {
    return null;
  }

  return (
    <div className="content_container">
      <div className="custom_container">
        <h2 className="content_heading">Top Categories</h2>
        <div ref={sliderRefB} className="keen-slider">
          {props.categoryList &&
            props.categoryList.map((category, index) => (
              <div className="keen-slider__slide" key={category._id}>
                <Category
                  name={category.name}
                  slug={category.slug}
                  img={category.icon[0].url}
                />
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}

export default CategoryList;
